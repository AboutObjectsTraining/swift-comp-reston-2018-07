//
//  Model.h
//  Model
//
//  Created by Jonathan Lehr on 7/26/18.
//  Copyright © 2018 About Objects. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for Model.
FOUNDATION_EXPORT double ModelVersionNumber;

//! Project version string for Model.
FOUNDATION_EXPORT const unsigned char ModelVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Model/PublicHeader.h>


